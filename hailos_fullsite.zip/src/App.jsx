import React from 'react'

function App() {
  return (
    <div style={{ 
      backgroundColor: '#0d0d0d', 
      color: 'white', 
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center'
    }}>
      <h1>Hailos Productions</h1>
      <p>Made with Emergent style ✨</p>
    </div>
  )
}

export default App
