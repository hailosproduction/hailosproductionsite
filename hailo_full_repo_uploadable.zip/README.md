# Hāịlō - Full Repo

Upload these files to a fresh GitHub repo and Netlify will build automatically.